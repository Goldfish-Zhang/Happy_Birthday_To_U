import streamlit as st

"This beautiful cat is displayed using `st.image`"
st.image("https://static.streamlit.io/examples/cat.jpg", caption="A cat", width=300)